﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
            con.Open();


            // checking for user existance ,whether user exist or not 
            //if user exist temp will tru thus show a mesaage the user exist already


            string checkuser = "select count(*) from UserData where UserName = '"+ TextBoxUserName.Text +"'";
            SqlCommand com = new SqlCommand(checkuser, con);
            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            if (temp == 1)
            {
                Response.Write("User Already Exists");
            }
            con.Close();
        }
    }
    protected void ButtonSubmit_Click(object sender, EventArgs e)
    {
        try
        {   //for each user here we are allocating a universal unique Id by GUI i.e Global Universal ID

            Guid newGUID= Guid.NewGuid();
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
            con.Open();

            //submit buttos action is to submit the data into database table i.e. in UserData
            //Make aQuerry For insertion 

            string insertQuery = "insert into UserData (Id,UserName, Email, Password, Profession) values(@Id,@Username, @Email, @Password, @Profession)";
            SqlCommand com = new SqlCommand(insertQuery, con);
            com.Parameters.AddWithValue("@Id", newGUID.ToString());
            com.Parameters.AddWithValue("@UserName", TextBoxUserName.Text);
            com.Parameters.AddWithValue("@Email", TextBoxEmail.Text);
            com.Parameters.AddWithValue("@Password", TextBoxPassword.Text);
            com.Parameters.AddWithValue("@Profession", DropDownProfession.SelectedItem.ToString());
            com.ExecuteNonQuery();

            //Response.Write("Registration is Successful");
            Response.Redirect("Manager.aspx");
            con.Close();

            // Response.Write("Your Registration is successful");
        }
        catch(Exception ex)
        {
            Response.Write("Error"+ex.ToString());
        }
    }

    protected void TextBoxUserName_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBoxEmail_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBoxPassword_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBoxConfirmPassword_TextChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownProfession_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ButtonExistingUserLogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
}