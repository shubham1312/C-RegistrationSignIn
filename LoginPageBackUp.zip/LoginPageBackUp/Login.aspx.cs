﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
        con.Open();


        // checking for user existance ,whether user exist or not 
        //if user exist temp will true thus show a mesaage the user exist already


        string checkuser = "select count(*) from UserData where UserName = '" + TextBoxLoginUserName.Text + "'";
        SqlCommand com = new SqlCommand(checkuser, con);
        int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
        con.Close();
        if (temp == 1)
        {
            // open connection
            //make querry for check password, access from database by con onject for selecting row
            //make ans string password for getting the password from table UserData
            //match password by if statement
            //
            con.Open();
            string checkpasswordQuerry = " select Password from UserData where UserName = '" + TextBoxLoginUserName.Text + "'";
            SqlCommand passcom = new SqlCommand(checkpasswordQuerry, con);
            string password = passcom.ExecuteScalar().ToString();
            con.Close();
            if (password == TextBoxLoginPassword.Text)
            {
                Session["New"] = TextBoxLoginUserName.Text;
                Response.Redirect("Pageafterlogin.aspx");
            }
            else
            {
               Response.Write("Please enter correct passowrd");
            }

        }
        else
        {
            Response.Write("UserName is not present");
        }
        

    }
    protected void ButtonNewUser_Click(object sender, EventArgs e)
    {
        Response.Redirect("Registration.aspx");
    }
    protected void Button_Login_Click(object sender, EventArgs e)
    {

    }
}